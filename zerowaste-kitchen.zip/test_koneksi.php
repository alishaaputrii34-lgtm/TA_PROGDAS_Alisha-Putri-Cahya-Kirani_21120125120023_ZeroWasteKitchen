<?php
include 'config.php';
echo"Koneksi Berhasil!";
?>
